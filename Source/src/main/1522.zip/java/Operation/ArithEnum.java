package Operation;

/**
 * Created by lijin on 5/22/19.
 */

public enum ArithEnum{
    OP_ADD,
    OP_SUB,
    OP_MUL,
    OP_MOD,

    OP_POW,
    OP_DIV,
    OP_IDIV,

    OP_BAND,
    OP_BOR,
    OP_BXOR,

    OP_SHL,
    OP_SHR,
    OP_UMN,
    OP_BNOT,
    ;

}
