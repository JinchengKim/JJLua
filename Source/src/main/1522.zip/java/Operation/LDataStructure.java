package Operation;

/**
 * Created by lijin on 5/23/19.
 */
public enum  LDataStructure {
    NIL,
    BOOLEAN,
    FUNCTION,
    LIGHTUSERDATA,
    NUMBER,
    STRING,
    TABLE,
    NULL,
    USERDATA;



}
