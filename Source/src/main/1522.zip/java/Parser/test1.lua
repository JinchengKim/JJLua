i = 1
i = i - 1
print(i)
