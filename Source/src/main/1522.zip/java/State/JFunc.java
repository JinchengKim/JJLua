package State;

/**
 * Created by lijin on 5/24/19.
 */
@FunctionalInterface
public interface JFunc {
    int invoke(LState ls);
}
