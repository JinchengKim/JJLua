package BinaryChunk;

import java.nio.ByteBuffer;

/**
 * Created by lijin on 5/22/19.
 */
public class BVar {
    public String varName;
    public int startPC;
    public int endPC;

    void read(ByteBuffer buf) {
        varName = BChunk.getLuaString(buf);
        startPC = buf.getInt();
        endPC = buf.getInt();
    }
}
