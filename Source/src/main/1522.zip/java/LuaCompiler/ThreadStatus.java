package LuaCompiler;

/**
 * Created by lijin on 5/27/19.
 */
public enum  ThreadStatus {
    OK,
    YIELD,
    ERRRUN,
    ERRSYNTAX,
    ERRMEM,
    ERRGCMM,
    ERRERR,
    ERRFILE,
    ;
}
