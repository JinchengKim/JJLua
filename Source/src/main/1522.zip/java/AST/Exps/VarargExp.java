package AST.Exps;

import AST.Exp;

/**
 * Created by lijin on 5/20/19.
 */
public class VarargExp  extends Exp{
}
