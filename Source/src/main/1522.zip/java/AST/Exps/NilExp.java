package AST.Exps;

import AST.Exp;

/**
 * Created by lijin on 5/9/19.
 */
public class NilExp extends Exp {
}
