package AST.Stats;

import AST.Stat;

/**
 * Created by lijin on 5/9/19.
 */
public class GotoStat extends Stat{
    public String name;
    public GotoStat(String name){this.name = name;}
}
