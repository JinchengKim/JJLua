package AST.Stats;

import AST.Stat;

/**
 * Created by lijin on 5/9/19.
 */
public class LabelStat extends Stat{
    public String name;
    public LabelStat(String name){
        this.name = name;
    }
}
