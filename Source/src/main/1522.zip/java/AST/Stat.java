package AST;

/**
 * Created by lijin on 5/8/19.
 */
public class Stat extends ASTNode {
}
